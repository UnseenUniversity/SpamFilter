/*
 * classifier.h
 *
 *  Created on: May 18, 2014
 *      Author: alexei
 */

#ifndef CLASSIFIER_H_
#define CLASSIFIER_H_

#include "util/utils.hpp"
#include "classes.hpp"


class default_classifier{

public:

	default_classifier(std::vector<def_class*>& classes)
		: classes(classes),
		  confusion_matrix( classes.size(), std::vector<int>(classes.size(), 0))
	{

	}

	virtual void k_fold_classification( int k ) = 0;


	std::vector<def_class*>& classes;
	std::vector< std::vector<int> > confusion_matrix;

};

class naive_bayes : public default_classifier{

public:

	naive_bayes(std::vector<def_class*>& classes)
		: default_classifier(classes)
	{

	}

	void k_fold_classification( int k ){

		int obj_count = 0;
		_for(i, classes){
			classes[i]->randomize_object_set();
			obj_count += classes[i]->objects.size();
		}

		// ...code
	}

	void classification()
	{
		int obj_count = 0;

		_for(i, classes){
			classes[i]->randomize_object_set();
			obj_count += classes[i]->objects.size();
		}

	}

	void reset_stats(){

		for_each(i, classes){
			for_each(j, classes){
				confusion_matrix[i][j] = 0;
			}
		}

	}

	void print_stats(std::ostream& os){

		os << "Stats: \n";

		os << "\t";
		for_each(i, classes){
			os << classes[i]->name << "\t";
		}
		os << "\n";

		for_each(i, classes){
			os << classes[i]->name << "\t";
			for_each(j, classes){
				os << confusion_matrix[i][j] << "\t";
			}
			os << "\n";
		}

		os << "\n";
	}

};




#endif /* CLASSIFIER_H_ */
